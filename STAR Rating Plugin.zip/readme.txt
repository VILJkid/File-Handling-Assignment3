How to use?
It's as simple as this:

<input type="number" id="rating-system">

Paste this script after your STAR linking scripts:

<script>
        // initialize with defaults
        // $("#rating-system").rating();

        // with plugin options
        $("#rating-system").rating({
            min: 0,
            max: 5,
            step: 0.5,
            size: 'lg'
        });
</script>

Paste these STAR linking scripts after Jquery CDN script:

<!-- Core Stylesheet -->
<link href="Star/css/star-rating.min.css" rel="stylesheet" />
<!-- Core JavaScript -->
<script src="Star/js/star-rating.min.js"></script>
<!-- Languages -->
<script src="Star/js//locales/de.js"></script>
<!-- krajee-fa Theme -->
<link href="Star/themes/krajee-fa/theme.min.css" rel="stylesheet" />
<script src="Star/themes/krajee-fa/theme.min.js"></script>
<!-- krajee-fas Theme -->
<link href="Star/themes/krajee-fas/theme.min.css" rel="stylesheet" />
<!--Hehe Boi-->
<script src="Star/themes/krajee-fas/theme.min.js"></script>
<!-- krajee-svg Theme -->
<link href="Star/themes/krajee-svg/theme.min.css" rel="stylesheet" />
<script src="Star/themes/krajee-svg/theme.min.js"></script>
<!-- krajee-uni Theme -->
<link href="Star/themes/krajee-uni/theme.min.css" rel="stylesheet" />
<script src="Star/themes/krajee-uni/theme.min.js"></script>